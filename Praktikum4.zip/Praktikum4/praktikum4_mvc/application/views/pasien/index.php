<div class="col-md-12">
    <h3>
        Daftar Pasien
    </h3>
    <table class="table">
        <thead>
            <tr>
                <th>#</th><th>kode</th><th>Nama</th><th>Gender</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $nomor=1;
                foreach ($list_pasien as $pasien)
                {
            
                
                    /* <td><?=$nomor?></td>
                    <td><?=$pasien->kode?></td>
                    <td><?=$pasien->nama?></td>
                    <td><?=$pasien->gender?></td> */
                
                        echo '<tr><td>'.$nomor.'</td>';
                        echo '<td>'.$pasien->kode.'</td>';
                        echo '<td>'.$pasien->nama.'</td>';
                        echo '<td>'.$pasien->gender.'</td>';
                        echo '</tr>';
                
            
                $nomor++;
            
                }
            ?>
        </tbody>
    </table>
</div>