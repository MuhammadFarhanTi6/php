<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {

    public function index()
	{
        $this->load->model ('pasien_model','pasien1');
        $this->pasien1->id=1;
        $this->pasien1->kode='100012';
        $this->pasien1->nama='Triomarandi';
        $this->pasien1->gender='L';

        $this->load->model ('pasien_model','pasien2');
        $this->pasien2->id=2;
        $this->pasien2->kode='100013';
        $this->pasien2->nama='ridwansyah';
        $this->pasien2->gender='L';

        $this->load->model ('pasien_model','pasien3');
        $this->pasien3->id=3;
        $this->pasien3->kode='100014';
        $this->pasien3->nama='siviani';
        $this->pasien3->gender='P';

        $list_pasien = [$this->pasien1, $this->pasien2, $this->pasien3];
        $data['list_pasien']= $list_pasien;
        
        $this->load->view('header');
        $this->load->view('pasien/index',$data);
        $this->load->view('footer');
	}
}